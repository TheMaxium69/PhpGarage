<?php

namespace Model;


class Garage extends Model
{

  protected $table = "garages";


}