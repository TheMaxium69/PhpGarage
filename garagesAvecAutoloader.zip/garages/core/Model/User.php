<?php

namespace Model;



class User extends Model
{
    protected $table = "users";
}