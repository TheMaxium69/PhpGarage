<?php
  

  require_once "core/autoloading.php";
  $controller = new \Controllers\Garage();
  $controller->suppr();