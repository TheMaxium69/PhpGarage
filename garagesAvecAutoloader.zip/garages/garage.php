<?php

//require_once "core/Controllers/Garage.php";
require_once "core/autoloading.php";

$controller = new \Controllers\Garage();
$controller->show();